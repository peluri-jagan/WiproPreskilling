﻿namespace LibraryManagement
{
    public class Class1
    {

    }
}
