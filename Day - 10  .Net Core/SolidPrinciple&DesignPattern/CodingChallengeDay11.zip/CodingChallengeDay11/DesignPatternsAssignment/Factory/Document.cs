namespace Factory
{
    public abstract class Document
    {
        public abstract void Print();
    }
}
