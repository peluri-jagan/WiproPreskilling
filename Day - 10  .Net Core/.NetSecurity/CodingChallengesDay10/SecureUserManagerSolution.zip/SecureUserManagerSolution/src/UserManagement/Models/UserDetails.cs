namespace UserManagement.Models
{
    public class UserDetails
    {
        public string FullName { get; set; } = "";
        public string Email { get; set; } = "";
    }
}
