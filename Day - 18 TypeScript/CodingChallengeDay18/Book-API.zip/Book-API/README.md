# Book Management API

A Node.js + Express project to manage books stored in a JSON file.

## Setup
```bash
npm install
npm start
